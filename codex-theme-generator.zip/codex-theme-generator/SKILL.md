---
name: codex-theme-generator
description: Create a complete Codex/ChatGPT desktop theme from scratch from a natural-language brief plus mixed source materials such as screenshots, logos, photos, SVGs, PDFs, brand manuals, Markdown, and existing UI references. Use when Codex needs to interpret a visual direction, extract documented brand rules, build a traceable design system and theme package, create home/thread responsive compositions, scaffold or extend a safe local CDP theme engine, generate previews, validate assets and accessibility, and deliver start/apply/pause/restore instructions.
---

# Codex Theme Generator

Turn an informal visual request and mixed source files into a traceable, reversible, live-tested Codex desktop theme. Build the visual system before styling the renderer.

## Define the delivery scope

Inspect the workspace before creating files.

- If a compatible theme engine already exists, create a theme package and the minimum required runtime contract changes.
- If only a visual theme is requested, do not rebuild the launcher or CDP engine.
- If no engine exists and the user requests a working desktop skin, build the theme package, preview, guarded injector, verifier, and recovery flow.
- Treat a static HTML preview as a design checkpoint, never as proof that the live Codex renderer works.

Ask only when a missing choice changes brand authorization, distribution rights, target platform, or product scope. Otherwise record a reasonable assumption and continue.

## Convert the request into an evidence pack

### 1. Inventory every input

Run:

```bash
node scripts/inventory_theme_sources.mjs <files-or-directories> --out <project>/references/source-manifest.json
```

Classify each input as:

- requirement or narrative;
- visual manual or policy;
- reusable brand asset;
- inspiration/reference image;
- screenshot of Codex state;
- font or vector source;
- existing implementation.

Do not treat a screenshot as a reusable logo, or an inspiration image as an official rule.

Read [references/source-intake.md](references/source-intake.md) for extraction commands, PDF/image handling, conflict resolution, and authorization rules.

### 2. Extract facts with provenance

For every decision, label the source as:

- **official**: explicitly stated by an authoritative manual or supplied asset;
- **derived**: calculated from official data, such as RGB-to-HEX conversion;
- **product**: introduced for Codex usability, such as dark panel opacity;
- **assumption**: temporary and awaiting confirmation.

Record source file, page or image, extracted value, status, confidence, and permitted use.

For PDFs, extract text with layout and render relevant pages. For images, inspect the actual pixels, dimensions, alpha channel, crop, embedded background, and safe area. Use OCR only as a supplement.

### 3. Write the design brief

Create these files in the output project:

```text
references/
├── source-manifest.json
├── visual-facts.md
├── visual-tokens.md
└── asset-ledger.md
theme-brief.md
```

Make `theme-brief.md` resolve:

- desired mood and forbidden directions;
- target platform and Codex views;
- brand prominence;
- home-versus-thread intensity;
- logo and text safe regions;
- light/dark behavior;
- motion tolerance;
- distribution and authorization boundary;
- definition of done.

Do not begin live CSS injection while these decisions are contradictory.

## Build the visual language

Translate adjectives into measurable choices. Do not copy the literal pixels of a reference unless the user explicitly requests a faithful adaptation and has the right to use it.

Create tokens for:

- official brand colors;
- product background, panels, alternate panels, text, muted text, lines, focus, and accent;
- semantic colors preserved from native Codex;
- typography roles and fallbacks;
- spacing, radius, blur, opacity, elevation, and motion;
- composition focus, safe area, image treatment, and responsive cutoffs.

Keep official, derived, and product tokens visibly separated in documentation. Check text, focus, icon, and control contrast.

Read [references/design-translation.md](references/design-translation.md) when translating natural language, composing imagery, placing branding, or differentiating pages.

## Prepare assets

- Preserve original files unchanged under `references/originals/` or outside the generated theme.
- Place only optimized runtime assets inside the theme package.
- Prefer authorized official lockups over reconstructed logo-plus-text arrangements.
- Do not redraw, stretch, retype, crop, recolor, or animate a protected mark unless the source rules allow it.
- Remove an unwanted rectangular background only when the foreground can be extracted faithfully.
- Generate decorative textures separately from protected marks.
- Record origin, transformation, checksum, license/authorization, and redistribution status in `asset-ledger.md`.
- Reject remote runtime URLs, absolute paths, traversal, symlink escape, oversized files, and executable assets.

## Design the view matrix

Create distinct compositions for:

| State | Required treatment |
|---|---|
| Home, sidebar open | Full visual identity, one brand lockup, clear composer safe zone |
| Home, sidebar collapsed | Reflow or reveal branding without colliding with native controls |
| Thread/task | Hide or greatly reduce branding; prioritize stable reading substrate |
| Composer expanded | Keep decorations outside the variable-height composer footprint |
| Narrow window | Hide nonessential decoration before shrinking protected marks |
| Menu/dialog open | Preserve native placement, stacking, and dismissal behavior |
| Reduced motion | Disable nonessential loops and transforms |

Use one coordinate system for related elements such as an orbit and centered lockup. Verify positions with bounding boxes.

## Implement the theme

Read [references/implementation-blueprint.md](references/implementation-blueprint.md) and choose the smallest applicable architecture.

### Theme package

Start from `assets/theme-package-template/theme.json` and replace every placeholder with evidence-backed values. Keep the package declarative.

Validate it:

```bash
node scripts/validate_theme_package.mjs <theme-directory>/theme.json
```

### Static preview

Build a local preview with:

- home/thread toggle;
- sidebar open/collapsed toggle;
- normal/expanded composer;
- narrow viewport;
- reduced motion;
- representative dialog or menu.

Expose useful theme controls only when they map to the final package schema. Mark safe areas.

### Live runtime

When building a standalone engine:

1. verify the official app identity and signature;
2. start CDP on an ephemeral `127.0.0.1` port;
3. verify listener ownership;
4. accept only the guarded main `type=page`, `app://` target;
5. inject variables, scoped styles, and non-interactive decoration;
6. reapply idempotently after route and DOM changes;
7. support apply, pause, resume, verify, and complete restore;
8. clean all DOM, classes, styles, scripts, observers, timers, listeners, and Blob URLs.

Never modify the signed `.app` or `app.asar`.

## Style the live renderer safely

- Maintain selector contracts in one module.
- Add page scope and geometry checks to ambiguous selectors.
- Add only namespaced runtime classes.
- Preserve native layout ownership for portals, poppers, sticky footers, scroll containers, composers, and measurement wrappers.
- Keep decorations `pointer-events: none`.
- Preserve native focus, selection, warning, error, approval, permission, diff, terminal, and accessibility semantics.
- Use the dedicated `$codex-theme-debugger` workflow if live testing reveals seams, leaked text fills, disappearing overlays, or native interaction regressions.

## Validate in increasing fidelity

1. Validate manifests, schema, paths, sizes, and authorization metadata.
2. Review the static preview at all matrix states.
3. Build and run automated tests.
4. Apply to the verified live Codex renderer.
5. Inspect computed styles and bounding boxes.
6. Capture fresh home and thread screenshots.
7. Test menus/dialogs with trusted interaction for at least three seconds.
8. Test route changes, reload, reduced motion, narrow width, expanded composer, and restore.

Use [references/release-checklist.md](references/release-checklist.md) as the release gate.

## Deliver a usable result

Provide:

- the complete runnable project or theme package;
- the static preview;
- source manifest, facts, tokens, and asset ledger;
- exact install/build/start/apply/pause/restore commands;
- validation report and representative screenshots;
- known assumptions and authorization limits;
- an explicit statement that the signed Codex application was not modified.

Do not call the result complete when only the preview looks correct.

## Bundled resources

- `scripts/inventory_theme_sources.mjs`: inventory and hash mixed input materials.
- `scripts/validate_theme_package.mjs`: validate a declarative theme and its local assets.
- `assets/theme-package-template/theme.json`: starter theme contract.
- `references/source-intake.md`: input extraction and provenance workflow.
- `references/design-translation.md`: natural-language-to-visual-system guidance.
- `references/implementation-blueprint.md`: project and runtime architecture.
- `references/release-checklist.md`: end-to-end acceptance matrix.
