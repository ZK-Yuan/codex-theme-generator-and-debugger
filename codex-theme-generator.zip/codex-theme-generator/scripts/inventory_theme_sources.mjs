#!/usr/bin/env node

import { createHash } from "node:crypto";
import { readFile, readdir, realpath, rename, stat, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
import process from "node:process";

const args = process.argv.slice(2);
const inputs = [];
let outputPath = null;

for (let index = 0; index < args.length; index += 1) {
  if (args[index] === "--out") {
    outputPath = args[index + 1] ? path.resolve(args[index + 1]) : null;
    index += 1;
    continue;
  }
  inputs.push(path.resolve(args[index]));
}

if (inputs.length === 0 || args.includes("--help") || args.includes("-h")) {
  process.stdout.write(
    "Usage: node inventory_theme_sources.mjs <file-or-directory> [...] [--out manifest.json]\n",
  );
  process.exitCode = inputs.length === 0 ? 1 : 0;
} else {
  await main();
}

async function main() {
  const warnings = [];
  const candidates = [];

  for (const input of inputs) {
    try {
      await collect(input, candidates);
    } catch (error) {
      warnings.push({
        path: displayPath(input),
        message: error instanceof Error ? error.message : String(error),
      });
    }
  }

  const files = [];
  for (const filePath of [...new Set(candidates)].sort()) {
    try {
      files.push(await describe(filePath));
    } catch (error) {
      warnings.push({
        path: displayPath(filePath),
        message: error instanceof Error ? error.message : String(error),
      });
    }
  }

  const hashes = new Map();
  for (const file of files) {
    const matches = hashes.get(file.sha256) || [];
    matches.push(file.path);
    hashes.set(file.sha256, matches);
  }

  const duplicates = [...hashes.entries()]
    .filter(([, matches]) => matches.length > 1)
    .map(([sha256, matches]) => ({ sha256, paths: matches }));

  const manifest = {
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    inputCount: inputs.length,
    fileCount: files.length,
    files,
    duplicates,
    warnings,
  };
  const serialized = `${JSON.stringify(manifest, null, 2)}\n`;

  if (outputPath) {
    await mkdir(path.dirname(outputPath), { recursive: true });
    const temporary = `${outputPath}.tmp-${process.pid}`;
    await writeFile(temporary, serialized, { mode: 0o600 });
    await rename(temporary, outputPath);
  }

  process.stdout.write(serialized);
}

async function collect(candidate, target) {
  const info = await stat(candidate);
  if (info.isFile()) {
    target.push(await realpath(candidate));
    return;
  }
  if (!info.isDirectory()) return;

  for (const entry of await readdir(candidate, { withFileTypes: true })) {
    if (
      entry.name === ".git" ||
      entry.name === "node_modules" ||
      entry.name === "dist" ||
      entry.name === "build" ||
      entry.name.startsWith(".DS_Store")
    ) {
      continue;
    }
    await collect(path.join(candidate, entry.name), target);
  }
}

async function describe(filePath) {
  const info = await stat(filePath);
  const buffer = await readFile(filePath);
  const extension = path.extname(filePath).toLowerCase();
  const classification = classify(filePath, extension);
  return {
    path: displayPath(filePath),
    name: path.basename(filePath),
    extension: extension || null,
    bytes: info.size,
    sha256: createHash("sha256").update(buffer).digest("hex"),
    category: classification.category,
    roleHint: classification.roleHint,
    media: inspectMedia(buffer, extension),
  };
}

function classify(filePath, extension) {
  const name = path.basename(filePath).toLowerCase();
  const hint =
    /logo|mark|wordmark|lockup|combination|reverse|校徽|标志|标准字|组合/.test(name)
      ? "brand-asset"
      : /manual|guide|guideline|规范|手册/.test(name)
        ? "visual-manual"
        : /screen|shot|screenshot|截屏|截图/.test(name)
          ? "ui-screenshot"
          : /font|type|字体/.test(name)
            ? "typography"
            : /requirement|brief|需求|方案/.test(name)
              ? "requirements"
              : "unclassified";

  if ([".png", ".jpg", ".jpeg", ".webp", ".gif", ".tif", ".tiff"].includes(extension)) {
    return { category: "raster-image", roleHint: hint };
  }
  if ([".svg", ".ai", ".eps"].includes(extension)) {
    return { category: "vector-image", roleHint: hint };
  }
  if (extension === ".pdf") return { category: "pdf", roleHint: hint };
  if ([".md", ".txt", ".rtf"].includes(extension)) {
    return { category: "text-document", roleHint: hint };
  }
  if ([".doc", ".docx", ".pages"].includes(extension)) {
    return { category: "word-document", roleHint: hint };
  }
  if ([".ppt", ".pptx", ".key"].includes(extension)) {
    return { category: "presentation", roleHint: hint };
  }
  if ([".ttf", ".otf", ".woff", ".woff2"].includes(extension)) {
    return { category: "font", roleHint: "typography" };
  }
  if ([".json", ".yaml", ".yml", ".css", ".scss", ".js", ".mjs", ".ts", ".tsx"].includes(extension)) {
    return { category: "implementation", roleHint: hint };
  }
  return { category: "other", roleHint: hint };
}

function inspectMedia(buffer, extension) {
  if (
    extension === ".png" &&
    buffer.length >= 26 &&
    buffer.subarray(1, 4).toString("ascii") === "PNG"
  ) {
    return {
      width: buffer.readUInt32BE(16),
      height: buffer.readUInt32BE(20),
      alphaHint: [4, 6].includes(buffer[25]),
    };
  }

  if ([".jpg", ".jpeg"].includes(extension)) {
    const dimensions = jpegDimensions(buffer);
    return dimensions ? { ...dimensions, alphaHint: false } : null;
  }

  if (extension === ".webp") {
    return webpDimensions(buffer);
  }

  if (extension === ".svg") {
    const source = buffer.subarray(0, 8192).toString("utf8");
    const viewBox = source.match(/\bviewBox\s*=\s*["']([^"']+)["']/i)?.[1];
    const width = source.match(/\bwidth\s*=\s*["']([\d.]+)(?:px)?["']/i)?.[1];
    const height = source.match(/\bheight\s*=\s*["']([\d.]+)(?:px)?["']/i)?.[1];
    return {
      width: width ? Number(width) : null,
      height: height ? Number(height) : null,
      viewBox: viewBox || null,
      alphaHint: true,
    };
  }

  if (extension === ".pdf") {
    const text = buffer.toString("latin1");
    return {
      pageCountHint: (text.match(/\/Type\s*\/Page\b/g) || []).length || null,
    };
  }

  return null;
}

function jpegDimensions(buffer) {
  if (buffer.length < 4 || buffer[0] !== 0xff || buffer[1] !== 0xd8) return null;
  const startOfFrame = new Set([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf]);
  let offset = 2;
  while (offset + 8 < buffer.length) {
    if (buffer[offset] !== 0xff) {
      offset += 1;
      continue;
    }
    const marker = buffer[offset + 1];
    offset += 2;
    if (marker === 0xd8 || marker === 0xd9) continue;
    if (marker === 0xda || offset + 2 > buffer.length) break;
    const length = buffer.readUInt16BE(offset);
    if (startOfFrame.has(marker) && offset + 7 <= buffer.length) {
      return {
        width: buffer.readUInt16BE(offset + 5),
        height: buffer.readUInt16BE(offset + 3),
        alphaHint: false,
      };
    }
    if (length < 2) break;
    offset += length;
  }
  return null;
}

function webpDimensions(buffer) {
  if (
    buffer.length < 30 ||
    buffer.subarray(0, 4).toString("ascii") !== "RIFF" ||
    buffer.subarray(8, 12).toString("ascii") !== "WEBP"
  ) {
    return null;
  }
  const kind = buffer.subarray(12, 16).toString("ascii");
  if (kind === "VP8X") {
    return {
      width: buffer.readUIntLE(24, 3) + 1,
      height: buffer.readUIntLE(27, 3) + 1,
      alphaHint: Boolean(buffer[20] & 0x10),
    };
  }
  if (kind === "VP8L" && buffer[20] === 0x2f) {
    const bits = buffer.readUInt32LE(21);
    return {
      width: (bits & 0x3fff) + 1,
      height: ((bits >>> 14) & 0x3fff) + 1,
      alphaHint: true,
    };
  }
  if (kind === "VP8 " && buffer.length >= 30) {
    return {
      width: buffer.readUInt16LE(26) & 0x3fff,
      height: buffer.readUInt16LE(28) & 0x3fff,
      alphaHint: false,
    };
  }
  return null;
}

function displayPath(filePath) {
  const relative = path.relative(process.cwd(), filePath);
  return relative && !relative.startsWith("..") && !path.isAbsolute(relative)
    ? relative
    : filePath;
}
