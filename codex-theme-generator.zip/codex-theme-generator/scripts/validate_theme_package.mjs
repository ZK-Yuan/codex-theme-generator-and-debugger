#!/usr/bin/env node

import { readFile, realpath, stat } from "node:fs/promises";
import path from "node:path";
import process from "node:process";

const input = process.argv[2];
if (!input || input === "--help" || input === "-h") {
  process.stdout.write("Usage: node validate_theme_package.mjs <theme.json>\n");
  process.exitCode = input ? 0 : 1;
} else {
  await main(path.resolve(input));
}

async function main(themePath) {
  const errors = [];
  const warnings = [];
  let theme;

  try {
    theme = JSON.parse(await readFile(themePath, "utf8"));
  } catch (error) {
    report([{ id: "theme-read", message: String(error) }], warnings, themePath);
    process.exitCode = 2;
    return;
  }

  const themeRoot = path.dirname(themePath);
  const requiredTop = [
    "schemaVersion",
    "engine",
    "id",
    "name",
    "description",
    "appearance",
    "image",
    "art",
    "colors",
    "effects",
    "legal",
  ];
  for (const key of requiredTop) {
    if (!(key in theme)) errors.push({ id: "required-field", message: `Missing ${key}` });
  }

  if (theme.schemaVersion !== 1) {
    errors.push({ id: "schema-version", message: "schemaVersion must equal 1" });
  }
  if (!/^[a-z0-9][a-z0-9-]{1,63}$/.test(theme.id || "")) {
    errors.push({ id: "theme-id", message: "id must be 2–64 lowercase letters, digits, or hyphens" });
  }
  if (!["auto", "dark", "light"].includes(theme.appearance)) {
    errors.push({ id: "appearance", message: "appearance must be auto, dark, or light" });
  }
  if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(theme.engine?.minVersion || "")) {
    errors.push({ id: "engine-version", message: "engine.minVersion must be semver" });
  }

  numberRange(errors, theme.art?.focusX, 0, 1, "art.focusX");
  numberRange(errors, theme.art?.focusY, 0, 1, "art.focusY");
  if (!["left", "right", "center"].includes(theme.art?.safeArea)) {
    errors.push({ id: "safe-area", message: "art.safeArea must be left, right, or center" });
  }
  if (!["ambient", "banner", "off"].includes(theme.art?.taskMode)) {
    errors.push({ id: "task-mode", message: "art.taskMode must be ambient, banner, or off" });
  }

  const requiredColors = [
    "background",
    "panel",
    "panelAlt",
    "accent",
    "accentAlt",
    "secondary",
    "brand",
    "text",
    "muted",
    "line",
  ];
  for (const key of requiredColors) {
    if (!validColor(theme.colors?.[key])) {
      errors.push({ id: "color", message: `colors.${key} must be 6-digit HEX or RGB/RGBA` });
    }
  }

  integerRange(errors, theme.effects?.blur, 0, 40, "effects.blur");
  numberRange(errors, theme.effects?.panelOpacity, 0.45, 1, "effects.panelOpacity");
  integerRange(errors, theme.effects?.radius, 0, 32, "effects.radius");
  if (!["off", "subtle"].includes(theme.effects?.motion)) {
    errors.push({ id: "motion", message: "effects.motion must be off or subtle" });
  }

  for (const key of ["assetSource", "redistribution"]) {
    const value = theme.legal?.[key];
    if (!value || value === "__REQUIRED__") {
      errors.push({ id: "legal", message: `legal.${key} must document source and permission` });
    }
  }

  await validateAsset(themeRoot, theme.image, "image", errors);
  if (theme.assets?.brandLockup) {
    await validateAsset(themeRoot, theme.assets.brandLockup, "assets.brandLockup", errors);
  } else {
    warnings.push({ id: "brand-lockup", message: "No brand lockup is declared" });
  }

  report(errors, warnings, themePath);
  if (errors.length > 0) process.exitCode = 2;
}

async function validateAsset(root, value, label, errors) {
  if (typeof value !== "string" || value.length === 0) {
    errors.push({ id: "asset-path", message: `${label} must be a non-empty relative path` });
    return;
  }
  if (
    /^[a-z][a-z0-9+.-]*:/i.test(value) ||
    value.startsWith("//") ||
    path.isAbsolute(value) ||
    value.startsWith("~") ||
    value.split(/[\\/]/).includes("..")
  ) {
    errors.push({ id: "asset-path", message: `${label} must stay inside the theme directory` });
    return;
  }
  if (!/\.(?:png|jpe?g|webp)$/i.test(value)) {
    errors.push({ id: "asset-type", message: `${label} must be PNG, JPEG, or WebP` });
    return;
  }

  const candidate = path.resolve(root, value);
  try {
    const resolvedRoot = await realpath(root);
    const resolvedAsset = await realpath(candidate);
    if (resolvedAsset !== resolvedRoot && !resolvedAsset.startsWith(`${resolvedRoot}${path.sep}`)) {
      errors.push({ id: "asset-escape", message: `${label} resolves outside the theme directory` });
      return;
    }
    const info = await stat(resolvedAsset);
    if (!info.isFile()) {
      errors.push({ id: "asset-file", message: `${label} is not a file` });
    } else if (info.size > 20 * 1024 * 1024) {
      errors.push({ id: "asset-size", message: `${label} exceeds 20 MiB` });
    }
  } catch (error) {
    errors.push({ id: "asset-read", message: `${label} cannot be read: ${String(error)}` });
  }
}

function validColor(value) {
  return (
    typeof value === "string" &&
    (/^#[0-9a-f]{6}$/i.test(value) ||
      /^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}(?:\s*,\s*(?:0|1|0?\.\d+))?\s*\)$/i.test(value))
  );
}

function numberRange(errors, value, minimum, maximum, label) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < minimum || value > maximum) {
    errors.push({ id: "number-range", message: `${label} must be between ${minimum} and ${maximum}` });
  }
}

function integerRange(errors, value, minimum, maximum, label) {
  if (!Number.isInteger(value) || value < minimum || value > maximum) {
    errors.push({ id: "integer-range", message: `${label} must be an integer between ${minimum} and ${maximum}` });
  }
}

function report(errors, warnings, themePath) {
  process.stdout.write(
    `${JSON.stringify(
      {
        themePath,
        valid: errors.length === 0,
        errors,
        warnings,
      },
      null,
      2,
    )}\n`,
  );
}
