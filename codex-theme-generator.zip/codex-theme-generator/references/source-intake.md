# Source intake and provenance

## Contents

1. Intake order
2. Natural-language brief
3. PDFs and documents
4. Images and vectors
5. Existing code
6. Source authority and conflicts
7. Authorization ledger

## 1. Intake order

1. Inventory inputs without transforming them.
2. Hash files and identify duplicates.
3. Separate requirements, rules, assets, references, screenshots, and code.
4. Extract machine-readable text and metadata.
5. Visually inspect the original or rendered pages.
6. Write facts before design decisions.
7. Preserve originals.

Do not silently skip unsupported or unreadable files. Record them in the source manifest with a warning.

## 2. Natural-language brief

Parse the request into:

| Dimension | Examples |
|---|---|
| Identity | university, laboratory, company, personal |
| Mood | restrained, engineering, ceremonial, playful, retro |
| Color | named brand color, warm/cool, dark/light |
| Density | minimal, information-rich, immersive |
| Brand prominence | hero, supporting, nearly invisible |
| Page behavior | home rich, task quiet, settings native |
| Motion | off, subtle, expressive |
| Constraints | no fake logo, no card, no gradients, must use supplied asset |
| Delivery | theme package, preview, standalone injector |

Distinguish a requirement from an example. “Like this image” is normally a direction for hierarchy, rhythm, material, or composition—not permission to copy protected artwork.

Convert vague terms into testable statements:

- “高级” → limited palette, consistent rhythm, no accidental gradients, restrained elevation.
- “科技感” → precise geometry, engineered spacing, controlled cyan/blue accents, not gratuitous neon.
- “学校元素多一些” → use approved lockup, color system, typography, and one auxiliary motif; do not repeat the logo.
- “不影响工作” → task background 4–8%, no brand over content, stable 82–92% reading substrate.

## 3. PDFs and documents

For a PDF:

1. Read metadata and page count.
2. Extract text with layout:

   ```bash
   pdftotext -layout manual.pdf manual.txt
   ```

3. Search the extracted text for color, typography, minimum size, clear space, reverse mark, digital media, forbidden usage, and licensing terms.
4. Render relevant pages:

   ```bash
   pdftoppm -f 8 -l 15 -png -r 150 manual.pdf rendered/page
   ```

5. Visually inspect the pages. Tables, swatches, diagrams, and logo proportions may not survive text extraction.
6. Record page numbers with every extracted rule.
7. Use OCR only when the text layer is missing; verify OCR against the rendered page.

For DOCX/PPTX or other packaged documents, use the relevant document/presentation tooling to extract both text and rendered visuals. Preserve page or slide references.

Never trust a printed HEX field when it visibly conflicts with the RGB/CMYK fields. Record the conflict and label any conversion as derived.

## 4. Images and vectors

For each image, determine:

- pixel dimensions and aspect ratio;
- alpha channel or embedded background;
- color mode/profile;
- whether it is a screenshot, protected mark, photograph, pattern, or inspiration;
- whether text is baked into pixels;
- whether crop or padding is meaningful;
- minimum usable display size;
- dark/light/reverse variants;
- source and authorization.

Use image inspection before editing. Keep the original intact. Derive runtime assets into a separate folder.

For a logo or lockup:

- prefer SVG or an official transparent raster;
- preserve the internal arrangement and aspect ratio;
- do not independently move a wordmark out of a protected combination;
- do not erase a background if that changes the mark itself;
- do not infer clear space from visual taste when the manual defines it.

For a screenshot:

- extract layout relationships and state information;
- do not reuse interface pixels as assets;
- record viewport and state if it documents a defect or desired behavior.

## 5. Existing code

Inspect:

- package scripts and runtime versions;
- theme schema and existing packages;
- launcher/CDP boundaries;
- selector contracts;
- preview implementation;
- tests and verification scripts;
- local dirty changes.

Extend an existing engine instead of duplicating it. Preserve unrelated user changes.

## 6. Source authority and conflicts

Use this precedence unless the user explicitly overrides it:

1. explicit user requirement and confirmed authorization;
2. official current visual manual;
3. official supplied asset;
4. project-specific requirements;
5. existing implementation;
6. reference screenshot;
7. aesthetic inference.

Do not hide conflicts. Add a row:

```text
Decision | Source A | Source B | Resolution | Status
```

If a conflict affects identity, legal use, or a protected mark, stop and request direction. If it affects a reversible product token, label the assumption and continue.

## 7. Authorization ledger

Track:

| Asset | Source | Owner | Allowed use | Transformation | Redistribution | Status |
|---|---|---|---|---|---|---|

“User says authorized” is sufficient for the scoped local implementation, but record that public redistribution remains governed by the actual authorization terms.
