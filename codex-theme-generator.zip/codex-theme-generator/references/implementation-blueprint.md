# Implementation blueprint

## Contents

1. Choose the build mode
2. Theme package
3. Static preview
4. Standalone engine
5. Selector contracts
6. State and recovery
7. Test architecture

## 1. Choose the build mode

### Mode A: theme package in an existing engine

Use when the workspace already contains a theme schema, loader, preview, and CDP runtime.

Deliver:

- theme JSON;
- optimized local assets;
- source/authorization notice;
- preview integration;
- only the selector/runtime additions needed by the design;
- package tests.

### Mode B: complete standalone skin tool

Use when no compatible engine exists and the user asks for a working Codex desktop theme.

Deliver:

- theme package;
- static preview;
- CLI or launcher;
- app identity verifier;
- loopback CDP discovery and target guard;
- renderer runtime and selector contracts;
- watcher/reload persistence;
- verification screenshots/report;
- complete restore.

## 2. Theme package

Keep it declarative. A useful schema includes:

```text
schemaVersion
engine.minVersion
id
name
description
appearance
image
assets.brandLockup
art.focusX / focusY / safeArea / taskMode
colors
effects
legal.assetSource / redistribution
```

Reject:

- remote URLs;
- absolute paths;
- `..` traversal;
- symlink escape;
- executable code;
- unsupported image types;
- excessive bytes or pixels;
- missing provenance.

## 3. Static preview

Implement the state matrix in one preview instead of separate mock screenshots. Use the same theme JSON and asset paths intended for runtime.

The preview should expose:

- view mode;
- sidebar state;
- composer state;
- viewport width;
- reduced motion.

Do not imitate native controls so precisely that preview elements could be mistaken for the real application in a generated background image.

## 4. Standalone engine

Suggested modules:

```text
src/
├── app/          discovery, identity, signing
├── cdp/          launch, listener ownership, target guard
├── theme/        schema, loader, assets, registry
├── runtime/      CSS, DOM decoration, selector contracts, cleanup
├── state/        locks, permissions, session identity
├── verify/       diagnostics, masking, screenshots, report
└── cli/          doctor, preview, start, apply, pause, resume, restore
```

Security invariants:

- verify official bundle identity and signature;
- bind CDP to `127.0.0.1` only;
- use an ephemeral port;
- verify listener PID and executable;
- accept only `type=page`, `app://`, loopback WebSocket targets;
- store minimal state with restrictive permissions;
- never log conversation text, project names, credentials, or API keys;
- never edit the signed application.

Handle existing app instances explicitly. Electron single-instance behavior may make a new process ignore CDP flags. Fail with a clear recovery instruction rather than waiting indefinitely or killing an unknown process.

## 5. Selector contracts

Keep contracts separate from CSS:

```ts
type SelectorContract = {
  key: string;
  selectors: string[];
  pageScopes: Array<"home" | "thread" | "settings">;
  className: string;
  required: boolean;
  stability: "stable" | "fallback" | "fragile";
};
```

For ambiguous elements, validate geometry and ancestry before applying the class.

Never use broad rules for:

- `span`;
- `mark`;
- `[data-state]`;
- `[class*=selected]`;
- all `nav[aria-label]`;
- Radix/Floating UI positioning wrappers.

Keep CSS focused on paint. Preserve native position, transform, size measurement, overflow, and stacking behavior unless the selector identifies a theme-owned element.

## 6. State and recovery

Implement:

- idempotent apply;
- hot theme switching;
- page/route reclassification;
- reload-safe early injection;
- session-scoped observer/watcher;
- pause and resume;
- complete cleanup;
- full native restart when requested.

Cleanup must remove injected DOM, classes, stylesheets, early scripts, observers, timers, listeners, and Blob URLs.

## 7. Test architecture

Automate:

- theme schema validation;
- path traversal and remote URL rejection;
- image type/size/pixel limits;
- app identity parsing;
- loopback listener ownership;
- target guard;
- state permission and lock behavior;
- idempotent runtime apply/cleanup;
- home/thread differentiation;
- reduced motion;
- brand asset integrity.

Live acceptance must additionally cover:

- sidebar open/collapsed;
- quick-jump rail;
- normal/expanded composer;
- menu/dialog persistence;
- route/reload persistence;
- code/diff/terminal readability;
- horizontal overflow;
- full restore.
