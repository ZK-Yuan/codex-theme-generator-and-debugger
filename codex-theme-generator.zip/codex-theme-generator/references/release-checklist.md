# Codex theme release checklist

## Inputs and provenance

- [ ] Every supplied file appears in `source-manifest.json`.
- [ ] Requirements, official rules, reusable assets, references, and screenshots are distinguished.
- [ ] Relevant PDF pages were rendered and visually inspected.
- [ ] Each official value cites a source and page/image.
- [ ] Derived and product values are clearly labeled.
- [ ] Conflicts and assumptions are recorded.
- [ ] Protected assets have authorization and redistribution notes.
- [ ] Original assets remain unchanged.

## Visual system

- [ ] The design brief converts the natural-language request into measurable decisions.
- [ ] Brand, product, and semantic token layers are separated.
- [ ] Text, muted text, focus, icons, and controls meet contrast requirements.
- [ ] The official lockup keeps its ratio, clear space, and minimum size.
- [ ] Decorative assets do not fabricate protected marks.
- [ ] Home and thread compositions are materially different.
- [ ] Narrow and reduced-motion modes are defined.

## Package and preview

- [ ] Theme JSON passes the bundled validator.
- [ ] Runtime asset paths are local, relative, and contained.
- [ ] Asset dimensions and sizes are bounded.
- [ ] Static preview covers the complete view matrix.
- [ ] Preview and runtime consume the same tokens and assets.
- [ ] Composer safe regions include attachment-expanded height.

## Runtime safety

- [ ] Official app identity and signature are verified.
- [ ] Signed `.app` and `app.asar` are untouched.
- [ ] CDP is loopback-only with verified listener ownership.
- [ ] Only the guarded main `app://` page is accepted.
- [ ] Decorations cannot intercept pointer input.
- [ ] Native semantic states remain readable.
- [ ] Selector rules are scoped and idempotent.
- [ ] Native popper/portal positioning is preserved.
- [ ] Complete cleanup and restore are implemented.

## Live visual QA

- [ ] Home screenshot, sidebar open.
- [ ] Home screenshot, sidebar collapsed.
- [ ] Thread screenshot with long text/code.
- [ ] Normal composer screenshot.
- [ ] Expanded composer screenshot.
- [ ] Narrow-window screenshot.
- [ ] Menu/dialog remains visible for at least three seconds.
- [ ] No seams at toolbar, sidebar, main surface, quick-jump rail, composer, or sticky footer.
- [ ] No protected mark is clipped, distorted, repeated, or obscured.
- [ ] No horizontal overflow.

## Persistence and handoff

- [ ] Route changes keep the correct page mode.
- [ ] Reload restores the theme.
- [ ] Pause and resume work.
- [ ] Restore returns the native appearance.
- [ ] Build and automated tests pass.
- [ ] Start/apply/pause/restore commands are documented.
- [ ] Known assumptions and authorization limits are reported.
