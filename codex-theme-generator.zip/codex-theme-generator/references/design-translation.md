# Design translation

## Contents

1. From language to a system
2. Token layers
3. Composition
4. Brand integration
5. Page modes
6. Responsive and motion rules

## 1. From language to a system

Translate the brief across five axes:

| Axis | Decide |
|---|---|
| Color | hue family, luminance range, accent frequency, semantic preservation |
| Material | solid, translucent, glass, paper, metal, blueprint |
| Geometry | radius, line weight, grid, orbit, diagonal, organic curve |
| Rhythm | spacing scale, density, grouping, whitespace |
| Identity | mark, typography, motif, slogan, image treatment |

Use at most one primary material metaphor and one supporting geometric motif. Repetition creates identity; accumulating effects creates noise.

Avoid generic “AI theme” defaults such as neon cyan on black, excessive glow, random grids, and constant animation unless the brief explicitly asks for them.

## 2. Token layers

Keep four layers:

```text
official.*  documented brand values
derived.*   conversions or accessible variants
product.*   Codex surface and interaction values
semantic.*  native success/warning/error/focus meanings
```

Recommended product tokens:

```text
background
backgroundElevated
panel
panelAlt
text
muted
line
accent
accentAlt
focus
radius
blur
panelOpacity
motion
```

Do not replace semantic warning/error colors with a brand color.

Check:

- body text contrast;
- muted text contrast;
- focus indicator contrast;
- icon/control visibility;
- code and diff readability;
- disabled versus active distinction.

## 3. Composition

Start with functional exclusion zones:

- sidebar and top toolbar;
- central title/project selector;
- composer and expanded attachment area;
- thread reading column;
- menus/dialogs and native floating controls.

Then assign visual regions:

- **identity region**: one protected lockup with required clear space;
- **art region**: geometry, photo, or pattern;
- **quiet region**: text and controls;
- **transition region**: smooth color bridge between native surfaces.

Do not place identity elements first and then discover that the composer covers them.

## 4. Brand integration

Prefer:

1. official lockup;
2. official standard colors;
3. approved typeface or documented fallback;
4. one permitted auxiliary motif;
5. product-derived texture.

Do not create a floating “brand card” unless the brief asks for a card. A transparent lockup integrated into the composition usually feels more native.

Use the mark once on the home view. Hide it in task views when it competes with content.

When a slogan is independent from the official lockup, align it by a shared container and measured spacing. When it belongs to the protected lockup, do not recompose it.

## 5. Page modes

### Home

- visual geometry: roughly 12–18%;
- one visible brand lockup;
- panel opacity: roughly 70–82%;
- art may occupy a right or upper supporting region;
- reserve a clean composer safety zone.

### Thread/task

- visual geometry: roughly 4–8%;
- brand lockup hidden;
- reading substrate: roughly 82–92%;
- motion off or nearly static;
- no artwork crossing code, diff, terminal, or composer regions.

### Settings and secondary pages

Prefer the native surface with token-level color adaptation. Do not force the home composition into every route.

These ranges are starting points, not official brand values. Adjust from screenshots and contrast measurements.

## 6. Responsive and motion rules

- Hide secondary decoration before shrinking a protected mark below its minimum size.
- Recompute composition when the sidebar collapses.
- Test attachment-expanded composer height.
- Avoid horizontal overflow.
- Stop looping animation under `prefers-reduced-motion`.
- Keep motion decorative, slow, and nonessential.
- Use one coordinate source for related elements.
- Verify with live bounding boxes at common and narrow widths.
