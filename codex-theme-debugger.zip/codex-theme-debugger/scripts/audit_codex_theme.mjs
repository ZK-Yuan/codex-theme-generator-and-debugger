#!/usr/bin/env node

import { readFile, readdir, stat } from "node:fs/promises";
import path from "node:path";
import process from "node:process";

const projectRoot = path.resolve(process.argv[2] || process.cwd());
const sourceRoot = path.join(projectRoot, "src");

async function exists(filePath) {
  return stat(filePath).then(
    () => true,
    () => false,
  );
}

async function collectFiles(directory) {
  const files = [];
  if (!(await exists(directory))) return files;
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (["node_modules", "dist", ".git", "tmp"].includes(entry.name)) continue;
    const candidate = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...(await collectFiles(candidate)));
    else if (/\.(?:css|js|mjs|cjs|ts|tsx)$/.test(entry.name)) files.push(candidate);
  }
  return files;
}

const files = await collectFiles(sourceRoot);
const contents = new Map();
for (const file of files) {
  contents.set(file, await readFile(file, "utf8"));
}
const joined = [...contents.values()].join("\n");
const findings = [];

function add(severity, id, message, evidence = null) {
  findings.push({ severity, id, message, ...(evidence ? { evidence } : {}) });
}

function requirePattern(id, pattern, message) {
  if (!pattern.test(joined)) add("error", id, message);
}

function forbidPattern(id, pattern, message) {
  const match = joined.match(pattern);
  if (match) add("error", id, message, match[0].slice(0, 180));
}

if (files.length === 0) {
  add("error", "source-missing", "No JS/TS/CSS files were found under src/.");
}

requirePattern(
  "loopback-cdp",
  /127\.0\.0\.1/,
  "Require an explicit loopback-only CDP boundary.",
);
requirePattern(
  "local-target",
  /app:/,
  "Require an app:// renderer target guard.",
);
requirePattern(
  "cleanup",
  /cleanup[\s\S]{0,6000}(disconnect|clearInterval|removeEventListener|revokeObjectURL)/,
  "Implement cleanup for observers, timers, listeners, and object URLs.",
);
requirePattern(
  "decor-pointer-events",
  /codex-skin-decor[\s\S]{0,1200}pointer-events:\s*none/,
  "Decorative layers must not intercept input.",
);
requirePattern(
  "view-modes",
  /codex-skin-view|detectView/,
  "Separate home and thread/settings presentation.",
);
requirePattern(
  "top-fade",
  /main-top-fade|app-shell-main-content-top-fade/,
  "Handle the native main-content top fade to prevent toolbar seams.",
);
requirePattern(
  "thread-footer-fade",
  /thread-footer-fade|data-thread-scroll-footer/,
  "Inspect or neutralize the native sticky thread-footer gradient.",
);

forbidPattern(
  "radix-wrapper-themed",
  /selectors\s*:[\s\S]{0,600}\[data-radix-popper-content-wrapper\]/,
  "Do not include the Radix positioning wrapper in overlay surface selectors.",
);
for (const [file, content] of contents) {
  const blockPattern = /([^{}]+)\{([^{}]*)\}/g;
  for (const match of content.matchAll(blockPattern)) {
    const selector = match[1];
    const declarations = match[2];
    if (!/composer|thread-footer|scroll-footer/i.test(selector)) continue;
    const spread = declarations.match(
      /box-shadow\s*:[^;{}]*0\s+0\s+0\s+(?:[1-9]\d|[1-9]\d{2,})px/i,
    );
    if (!spread) continue;
    add(
      "error",
      "large-spread-shadow",
      "Large spread shadows around the composer create rectangular seams.",
      `${path.relative(projectRoot, file)}: ${spread[0].slice(0, 140)}`,
    );
  }
}
forbidPattern(
  "global-span-rule",
  /(?:^|[}\n])\s*(?:span|mark|\[data-state\]|\[class\*=["']selected["']\])\s*(?:,|\{)/m,
  "Avoid global text/state selectors; scope them to a runtime class.",
);

if (/nav\[aria-label\]/.test(joined)) {
  if (
    !/contract\.key\s*===\s*["']sidebar["'][\s\S]{0,900}rect\.left[\s\S]{0,900}rect\.height/.test(
      joined,
    )
  ) {
    add(
      "warning",
      "sidebar-geometry",
      "nav[aria-label] can match the quick-jump rail; add left-edge and height checks.",
    );
  }
}

for (const [file, content] of contents) {
  const overlayBlock = content.match(
    /\.codex-skin-overlay-surface\s*\{([\s\S]*?)\}/,
  )?.[1];
  if (overlayBlock && /\b(?:position|z-index|inset|top|right|bottom|left)\s*:/.test(overlayBlock)) {
    add(
      "error",
      "overlay-position-override",
      "Overlay visual CSS must not override native positioning or z-index.",
      path.relative(projectRoot, file),
    );
  }
}

const order = { error: 0, warning: 1, info: 2 };
findings.sort((left, right) => order[left.severity] - order[right.severity]);
const summary = {
  projectRoot,
  filesScanned: files.length,
  errors: findings.filter((item) => item.severity === "error").length,
  warnings: findings.filter((item) => item.severity === "warning").length,
  findings,
};

process.stdout.write(`${JSON.stringify(summary, null, 2)}\n`);
if (summary.errors > 0) process.exitCode = 2;
