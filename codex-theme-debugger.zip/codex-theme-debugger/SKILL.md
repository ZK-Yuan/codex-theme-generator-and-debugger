---
name: codex-theme-debugger
description: Diagnose and repair an existing Codex/ChatGPT desktop theme without changing native behavior or the signed application. Use when screenshots or reproduction steps show color seams, dark gradient bands, text background leakage, clipped or overlapping branding, sidebar or quick-jump misclassification, composer paint defects, disappearing Radix menus/dialogs, reload persistence failures, CDP start errors, or incomplete cleanup.
---

# Codex Theme Debugger

Fix the smallest responsible runtime layer. Preserve native layout, interaction, and signed-app integrity.

## Establish the defect

1. Read the screenshot annotations and reproduction steps.
2. Record the route, viewport, sidebar state, composer state, and action that opens the affected surface.
3. Separate visible symptoms from suspected causes.
4. Reproduce in the live Codex renderer. Do not diagnose from the static preview alone.
5. Capture a baseline screenshot before editing.

Read [references/failure-modes.md](references/failure-modes.md) when the symptom is a seam, dark block, selector leak, brand collision, transient popover, CDP timeout, or reload failure.

## Inspect the actual paint owner

At each defect boundary:

1. Sample with `elementsFromPoint`.
2. Inspect the element, ancestors, overlapping siblings, portal wrappers, and `::before`/`::after`.
3. Record computed background, background image, shadow, border, filter, backdrop filter, mask, opacity, position, transform, overflow, and z-index.
4. Compare the responsible paint rectangle with the visible defect rectangle.
5. Search packaged source strings for stable native classes or data attributes when DOM purpose is unclear.

Use the probes in [references/runtime-inspection.md](references/runtime-inspection.md).

## Apply narrow fixes

- Scope every rule to an injected runtime class and page mode.
- Prefer a stable semantic attribute plus a geometry constraint.
- Treat the outer `.main-surface` as distinct from inner content surfaces.
- Distinguish the full sidebar from the compact thread quick-jump rail.
- Inspect the composer, its ancestors, sticky footer, gradient child, and scroll masks separately.
- Style actual `[role=menu]` and `[role=dialog]` content surfaces.
- Never style `[data-radix-popper-content-wrapper]`.
- Never globally style `span`, `mark`, `[data-state]`, or `[class*=selected]`.
- Do not override native popper position, inset, transform, z-index, measurement width/height, or portal overflow.
- Keep branding hidden on task pages unless the theme contract explicitly requires otherwise.
- Keep decorative layers non-interactive.

Make contract reapplication idempotent. Remove stale classes when route or geometry changes.

## Preserve safety

- Never edit `.app`, `app.asar`, signed resources, model settings, login state, API endpoints, or network behavior.
- Keep CDP loopback-only and guard the verified `app://` page target.
- Preserve native warning, error, approval, permission, diff, terminal, focus, and selection semantics.
- Keep cleanup complete and reversible.
- Fail closed on app identity, target, or listener mismatch.

## Verify the repair

1. Hot apply the change.
2. Re-read computed styles; do not accept source text alone as proof.
3. Capture a fresh live screenshot at the same viewport.
4. Exercise both home and thread views.
5. Test normal and attachment-expanded composer states.
6. Keep a menu or dialog open for at least three seconds using trusted interaction.
7. Test sidebar open/collapsed, quick-jump rail, route change, reload, reduced motion, and restore.
8. Run:

```bash
node scripts/audit_codex_theme.mjs /absolute/path/to/project
npm run build
npm test
```

Use [references/acceptance-checklist.md](references/acceptance-checklist.md) as the regression gate.

## Completion criteria

Finish only when:

- the exact marked defect is absent in a new live screenshot;
- no adjacent native component regressed;
- menus and dialogs remain positioned and persistent;
- the theme survives supported route/reload transitions;
- full restore returns the official appearance;
- the signed application remains untouched.

## Bundled resources

- `scripts/audit_codex_theme.mjs`: flag known high-risk selector and paint patterns.
- `references/failure-modes.md`: map recurring symptoms to responsible layers.
- `references/runtime-inspection.md`: provide live DOM/CDP inspection probes.
- `references/acceptance-checklist.md`: define the regression matrix.
