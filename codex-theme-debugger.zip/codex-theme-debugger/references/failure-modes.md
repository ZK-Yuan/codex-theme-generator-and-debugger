# Codex theme failure modes

## Contents

1. Color seams and dark rectangles
2. Selector leakage
3. Popovers and dialogs
4. Brand asset failures
5. CDP lifecycle failures
6. Verification traps

## 1. Color seams and dark rectangles

| Symptom | Likely cause | Confirm | Narrow fix |
|---|---|---|---|
| Black strip below the top toolbar | Native `.app-shell-main-content-top-fade` | Inspect its 16px rect, gradient and opacity | Mark the native fade and make only its paint transparent |
| Large rectangle behind the composer | Sticky thread footer gradient sibling | Inspect `[data-thread-scroll-footer=true]` descendants; look for `bg-gradient-to-t` | Clear the gradient child, not the sticky footer |
| Composer surrounded by a dark block | Large spread shadow such as `0 0 0 72px`, exterior shadow, or a custom bottom wash | Compare composer rect with painted rect and inspect box-shadow | Remove exterior spread and wash; keep at most an inset highlight |
| Vertical seam beside sidebar | Outer `.main-surface`, sidebar parent, or native pseudo-element still paints a different color | Inspect the x-coordinate boundary with `elementsFromPoint` | Theme the outer surface or remove only the responsible pseudo paint |
| Blue block behind quick-jump ticks | Compact `nav[aria-label]` misclassified as sidebar | Check rect: often about 36px wide and short | Require sidebar to touch the left edge and be near full height |
| Thread text competes with geometry | Home strength reused on task page | Inspect route detection and decoration opacity | Hide brand; reduce geometry to 4–8%; add one stable reading substrate |

Never hide a seam by growing a shadow. That creates another seam at a different window size.

## 2. Selector leakage

### Dangerous patterns

- `span { ... }`
- `mark { ... }`
- `[data-state] { ... }`
- `[class*=selected] { ... }`
- `nav[aria-label]` without geometry checks
- broad descendants under the entire root

Typical outcomes:

- title words receive a rectangular fill;
- dotted underlines appear in ordinary headings;
- “new task” and current project both look selected;
- compact thread navigation receives the sidebar background.

Create a runtime class for the exact target and style that class. Reapply the class idempotently when the route changes.

## 3. Popovers and dialogs

Radix/Floating UI owns the wrapper position. Do not theme:

```css
[data-radix-popper-content-wrapper] {
  position: relative;
  z-index: 20;
}
```

This can make a popup flash, move, clip, or close after the mutation observer reapplies classes.

Style only the visible `[role=menu]` or `[role=dialog]` surface. Do not override its positioning, transform, inset, measurement dimensions, or portal wrapper.

Validate with trusted mouse input:

1. dispatch mouse moved/pressed/released at the trigger center;
2. inspect at about 80ms, 400ms, 1.5s, and 3s;
3. require the wrapper to preserve native `position: fixed` and native z-index;
4. require the menu/dialog to remain visible;
5. close with Escape.

Programmatic `element.click()` may not be treated as trusted input and is not sufficient evidence.

## 4. Brand asset failures

| Failure | Prevention |
|---|---|
| Fake or redrawn emblem | Require an authorized official source |
| Blue rectangular card behind a white logo | Extract/use an asset with real alpha; inspect corner alpha |
| Logo and wordmark appear misaligned | Use the full official combination asset instead of separate layers |
| Brand misses orbit center | Drive both from one x/y token and compare bounding-box centers |
| Brand overlaps composer or right panel | Define a safe region and hide the brand on thread/settings/narrow views |
| Logo too small | Enforce the source manual’s digital minimum width |

Never infer official safe-area ratios when the manual does not state them. Label product layout padding as a product rule.

## 5. CDP lifecycle failures

### `CDP_START_TIMEOUT`

Electron single-instance behavior usually handed the launch request to an already running process that lacks the new debugging arguments.

1. Detect existing official app PIDs before launch.
2. Return an immediate, explicit error.
3. Ask the user to quit normally or use a controlled launcher with confirmation.
4. Never kill an unknown process automatically.

### Identity or signature failure

Stop. Re-verify outside any sandbox that can interfere with system identity tools. Do not weaken Team ID, Bundle ID, executable-path, PID, listener, or target checks.

### Theme disappears after reload

Register a reload-safe early script and a session watcher. On apply, replace the prior early-script identifier. On restore, remove it.

## 6. Verification traps

- A static preview proves composition, not Codex compatibility.
- A passing build proves syntax, not layout.
- A style rule in source proves intent, not computed output.
- A transparent ancestor does not rule out a painted sibling.
- A one-frame visible popup does not prove persistence.
- A hidden brand on thread view should not fail intrinsic-width validation as if it were visible.
- A screenshot taken before hot apply must not be used to judge the new version.

Require both computed-style evidence and a fresh live screenshot.
