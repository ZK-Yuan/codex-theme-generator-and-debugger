# Codex theme acceptance checklist

## Security and recovery

- [ ] Official app signature, Bundle ID, Team ID, executable, architecture, and PID verified.
- [ ] CDP listens only on `127.0.0.1`.
- [ ] Listener ownership and `app://` main target verified.
- [ ] Theme package rejects remote URLs, path traversal, unsafe symlinks, executable code, and invalid images.
- [ ] No signed application file changed.
- [ ] Pause and complete restore work.
- [ ] Cleanup removes styles, DOM, classes, observers, timers, listeners, early scripts, and Blob URLs.

## Visual source integrity

- [ ] Official and product-derived tokens are labeled separately.
- [ ] Asset source and redistribution terms are recorded.
- [ ] Brand lockup is official/authorized, proportional, and not redrawn.
- [ ] Alpha, intrinsic dimensions, aspect ratio, minimum size, clipping, and center alignment verified.
- [ ] Brand is hidden on thread/settings and narrow layouts when required.

## Home

- [ ] No top-toolbar fade seam.
- [ ] No title word receives an accidental fill, underline, outline, or selected state.
- [ ] New-task button has only the intended default/hover/active states.
- [ ] Main and sidebar meet without a bridge block or abrupt color change.
- [ ] Composer does not overlap the brand.
- [ ] Background geometry stays below text and control contrast thresholds.

## Thread/task

- [ ] Brand is absent.
- [ ] Geometry is 4–8% and static or nearly static.
- [ ] Reading substrate is stable behind text, code, diff, and terminal.
- [ ] Quick-jump rail background is transparent and its ticks remain interactive.
- [ ] Composer exterior has no spread shadow or rectangular wash.
- [ ] Sticky thread footer gradient does not create a larger dark rectangle.
- [ ] Normal, attachment-expanded, and wide composer states pass.
- [ ] Scroll-to-latest, sticky footer, and scroll padding still work.

## Floating surfaces

- [ ] Menus, dialogs, listboxes, tooltips, and usage/reset popovers open in the right place.
- [ ] Radix/Floating UI wrapper retains native position, transform, inset, and z-index.
- [ ] Popup stays visible for at least three seconds.
- [ ] Escape and light-dismiss work.
- [ ] Theme classes apply only to visible surfaces, not positioning wrappers.

## Responsive and accessibility

- [ ] Sidebar open and collapsed.
- [ ] Right panel open and collapsed.
- [ ] Narrow and wide windows.
- [ ] No horizontal overflow above 2px.
- [ ] `prefers-reduced-motion` disables decorative animation.
- [ ] Keyboard focus remains visible.
- [ ] Native semantic colors remain recognizable.
- [ ] Text, muted text, and accent contrast meet the project thresholds.

## Persistence and release

- [ ] Route changes reapply idempotently.
- [ ] Reload restores the theme.
- [ ] Hot switch replaces the prior early script.
- [ ] Build succeeds.
- [ ] Automated tests succeed.
- [ ] Static audit has no errors.
- [ ] Fresh home and thread screenshots reviewed.
- [ ] Start, apply, pause, resume, verify, and restore instructions delivered.
