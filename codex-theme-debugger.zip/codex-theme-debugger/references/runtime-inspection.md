# Runtime inspection patterns

## Contents

1. Describe a live element
2. Find the painter at a seam
3. Inspect composer layers
4. Verify popover persistence
5. Search native application source

## 1. Describe a live element

Evaluate inside the verified renderer:

```js
function describe(element) {
  if (!element) return null;
  const rect = element.getBoundingClientRect();
  const style = getComputedStyle(element);
  const before = getComputedStyle(element, "::before");
  const after = getComputedStyle(element, "::after");
  return {
    tag: element.tagName.toLowerCase(),
    className: typeof element.className === "string" ? element.className : null,
    rect: {
      left: rect.left,
      top: rect.top,
      right: rect.right,
      bottom: rect.bottom,
      width: rect.width,
      height: rect.height,
    },
    background: style.background,
    boxShadow: style.boxShadow,
    maskImage: style.maskImage,
    filter: style.filter,
    backdropFilter: style.backdropFilter,
    position: style.position,
    zIndex: style.zIndex,
    before: { content: before.content, background: before.background },
    after: { content: after.content, background: after.background },
  };
}
```

## 2. Find the painter at a seam

Sample both sides of the visual boundary:

```js
const samples = [
  [x - 1, y],
  [x + 1, y],
].map(([px, py]) => ({
  point: { x: px, y: py },
  stack: document.elementsFromPoint(px, py).slice(0, 12).map(describe),
}));
```

Compare the first element that paints a non-transparent background, gradient, shadow, mask, or pseudo-element.

## 3. Inspect composer layers

Inspect all of these:

- `.composer-surface-chrome`;
- up to ten ancestors;
- `[data-thread-scroll-footer=true]`;
- footer descendants with computed gradient backgrounds;
- overlapping siblings from `elementsFromPoint`;
- decorative bottom washes;
- expanded-composer state;
- attachment previews and scroll-to-latest controls.

A known native footer structure is:

```text
[data-thread-scroll-footer=true]
└── absolute pointer-events-none fade container
    └── gradient paint child
```

Clear only the paint child. Keep the sticky footer and its measurement observer intact.

## 4. Verify popover persistence

Use trusted CDP mouse input at the trigger center. Record visible:

```css
[role="dialog"],
[role="menu"],
[role="listbox"],
[data-radix-popper-content-wrapper]
```

At multiple delays, record:

- rect;
- `data-state`;
- position;
- z-index;
- transform;
- visibility/display/opacity;
- whether the theme class is on the wrapper or only the surface.

Pass only when the popup remains visible for at least three seconds and the positioning wrapper retains native position and z-index.

## 5. Search native application source

When a stable data attribute is visible but its purpose is unclear, search the installed app read-only:

```bash
rg -a -n "data-thread-scroll-footer|app-shell-main-content-top-fade" \
  /Applications/ChatGPT.app/Contents/Resources/app.asar
```

Use this only to identify a stable DOM contract. Never edit or extract back into the signed application bundle.
